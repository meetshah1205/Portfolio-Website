print(eval(f'{input()}'))
